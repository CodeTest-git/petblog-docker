from captcha.fields import CaptchaField
from django import forms
from django.core.exceptions import ValidationError
from django.core.validators import MinLengthValidator, MaxLengthValidator
from django.utils.deconstruct import deconstructible

from .models import Category, Boyfriend, Woman


# зададим свой валидатор
# имеет смысл при многократном использовании
@deconstructible
class RussianValidator:
    ALLOWED_CHARS = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЬЫЪЭЮЯабвгдеёжзийклмнопрстуфхцчшщьыъэюя0123456789- "
    code = 'russian'

    def __init__(self, message=None):
        self.message = message if message else "Должны присутствовать только русские символы, дефис и пробел."

    # вызывается, когда срабатывает валидатор
    def __call__(self, value, *args, **kwargs):
        if not(set(value) <= set(self.ALLOWED_CHARS)):
            raise ValidationError(self.message, code=self.code)


# зададим класс для автоматизации создания форм не связанных с моделями - в комментариях, наследуем от forms.Form
# реализуем класс для автомазации форм связанных с моделями
class AddPostForm(forms.ModelForm):
    # через параметр label мы можем менять названия полей, а empty_label - это отображение варианта вместо черточек
    # initial - устанавливает начальное значение для параметра
    # title = forms.CharField(max_length=255, min_length=5,
    #                         label="Заголовок",
    #                         widget=forms.TextInput(attrs={'class': 'form-input'}),
    #                         validators = [
    #                             RussianValidator(),
    #                         ],
    #                         error_messages={
    #                             'min_length': 'Слишком короткий заголовок',
    #                             'required': 'Без заголовка никак',
    #                         })
    # slug = forms.SlugField(max_length=255, label="URL",
    #                        validators=[
    #                            MinLengthValidator(5, message="Минимум 5 символов"),
    #                            MaxLengthValidator(100, message="Максимум 100 символов")
    #                        ])
    # content = forms.CharField(widget=forms.Textarea(attrs={'cols': 50, 'rows':5}), required=False, label="Контент")
    # is_published = forms.BooleanField(required=False, label="Статус", initial=True)
    cat = forms.ModelChoiceField(queryset=Category.objects.all(), empty_label="Категория не выбрана" , label="Категории")
    boyfriend = forms.ModelChoiceField(queryset=Boyfriend.objects.all(), required=False, empty_label="Без парня" , label="Парень")

    class Meta:
        model = Woman
        fields = ['title', 'slug', 'content', 'photo', 'is_published', 'cat', 'boyfriend', 'tags']
        # подключаем css-стили
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-input'}),
            'content': forms.Textarea(attrs={'cols':50, 'rows': 5}),
        }
        labels = {'slug': 'URL'}

    # валидатор при единоразовом использовании
    def clean_content_and_title(self):
        content = self.cleaned_data['content']
        title = self.cleaned_data['title']

        ALLOWED_CHARS = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЬЫЪЭЮЯабвгдеёжзийклмнопрстуфхцчшщьыъэюя0123456789- "

        if not (set(content) <= set(ALLOWED_CHARS)):
            raise ValidationError("Должны присутствовать только русские символы, дефис и пробел.")

        if len(title) > 50:
            raise ValidationError("Длина превышает 50 символов")

        return content, title

# сформируем класс для создания форм не связанных с моделями
class UploadFileForm(forms.Form):
    file = forms.FileField(label="Файл")

class ContactForm(forms.Form):
    """
    Класс для отображения формы страницы обратной связи
    С вводом капчи
    """
    name = forms.CharField(label='Имя', max_length=255)
    email = forms.EmailField(label='Email')
    content = forms.CharField(widget=forms.Textarea(attrs={'cols':60, 'rows': 10}))
    captcha = CaptchaField()