from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.paginator import Paginator
from django.http import HttpResponse, HttpResponseNotFound, Http404, HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from django.template.defaultfilters import slugify
from django.urls import reverse, reverse_lazy
from datetime import datetime
# импортируем функцию обработки шаблонов
# по умолчанию джанго ищет их в подкаталоге templates, нужно его создать
from django.template.loader import render_to_string
from django.views import View
from django.views.generic import TemplateView, ListView, DetailView, FormView, CreateView, UpdateView

import users.views
from .forms import AddPostForm, UploadFileForm, ContactForm
from .models import Woman, Category, TagPost, UploadFiles
from .utils import DataMixin

"""
F12 или Ctrl + Shift + I -> очистка кэша и жесткая перезагрузка
"""

"""
Коды перенаправлений:

• 301 - страница перемещена на другой постоянный url-адрес
• 302 - страница перемещена временно на другой url-адрес

Помимо функции redirect, мы можем использовать следующие классы:

• HttpResponseRedirect - для редиректа с кодом 302
• HttpResponcePermanentRedirect - для редиректа с кодом 301
"""

"""
Виды запросов:
1. GET: Запрашивает представление ресурса. 
Этот запрос не должен оказывать никакого воздействия на ресурс.

2. DELETE: Удаляет указанный ресурс. 
Этот метод предназначен для удаления информации в указанном ресурсе.

3. PATCH: Применяет частичные изменения к ресурсу. 
Этот метод позволяет обновлять ресурс с частичными данными, а не полностью.

4. POST: Отправляет данные для обработки к определенному ресурсу. 
Часто используется для создания нового ресурса.

5. PUT: Обновляет целевой ресурс или создает новый ресурс, если он не существует. 
Полностью заменяет текущее представление целевого ресурса новым.
"""

"""
Оптимизация загрузки данных на странице:

• select_related('key') - "жадная" загрузка связанных данных по внешнему
ключу key, который имеет тип ForeignKey; Загружается на страницу сразу

• prefetch_related('key') - "жадная" загрузка связанных данных по внешнему 
ключу key, который имеет тип ManyToManyField
"""

"""
Классы-представления:
• View - общий базовый класс для представлений
• TemplateView - для отображения шаблона по GET-запросу
• ListView - для отображения нескольких записей в шаблоне по GET-запросу
• DetailView - для отображения одной записи в шаблоне по GET-запросу
• FormView - для обработки форм (используется GET и POST-запросы)
• CreateView - для создания (добавления) новых записей в БД с использованием форм
• UpdateView - для изменения существующих записей в БД с использованием форм
• DeleteView - для удаления записей из БД
"""

# Create your views here.

menu = [
    {'title': "О сайте", 'url_name': 'about'},
    {'title': "Добавить статью", 'url_name': 'add_page'},
    {'title': "Обратная связь", 'url_name': 'contact'},
    {'title': "Войти", 'url_name': 'login'}
]

# data_db = [
#     {'id': 1, 'title': 'Анджелина Джоли', 'content': '''<h1>Анджелина Джоли</h1> (англ. Angelina Jolie[7], при рождении Войт (англ. Voight), ранее Джоли Питт (англ. Jolie Pitt); род. 4 июня 1975, Лос-Анджелес, Калифорния, США) — американская актриса кино, телевидения и озвучивания, кинорежиссёр, сценаристка, продюсер, фотомодель, посол доброй воли ООН.
#
#         Обладательница премии «Оскар», трёх премий «Золотой глобус» (первая актриса в истории, три года подряд выигравшая премию) и двух «Премий Гильдии киноактёров США».''',
#
#      'is_published': True},
#     {'id':2, 'title': 'Марго Робби', 'content': 'Биография Марго Робби', 'is_published':False},
#     {'id':3, 'title': 'Джулия Робертс', 'content': 'Биография Джулия Робертс', 'is_published':True},
#     {'id':4, 'title': 'Ульяна Vershyga', 'content': '''<h1>Ульяна Vershyga</h1> (англ. Ulyana Vershyga; род. 10 января 2005, Нижний Тагил, Свердловская область, Россия) - Российская журналистка, участница премии "ШУМ", обладательница диплома "Золотой Гонг" (первая журналистка в Нижнем Тагиле, победившая сразу в двух номинациях) Заработала миллион в двадцать лет''','is_published':True}
# ]

# cats_db = [
#     {'id':1, 'name':'Актрисы'},
#     {'id':2, 'name':'Певицы'},
#     {'id':3, 'name':'Спортсменки'},
#     {'id':4, 'name':'Журналистки'},
# ]


def best(request):
    # для оптимизации sql-запросов на странице связываем по внешнему ключу cat
    posts = Woman.published.all().select_related('cat')
    data = {
        'title': 'Главная страница',
        'menu': menu,
        'float': 28.56,
        'lst': [1, 2, 'abc', True],
        'set': {1, 2, 3, 2, 5},
        'dict': {'key1': 'value_1', 'key2': 'value_2'},
        'posts': posts,
        'url': slugify("The Main Page"), # используем фильтры
    }  # создаем словарь с передаваемыми в шаблон значениями
    return render(request, 'woman/home_page.html', context=data) # то же самое, что и HttpResponse в функции index, только в одну строку

# класс-представление для отображения домашней страницы, наследуется от TemplateView
class WomanHome(DataMixin, ListView):
    # в template_name указываем путь к шаблону, который будет использоваться
    template_name = 'woman/home_page.html'
    context_object_name = 'posts'
    title_page = 'Главная страница'
    cat_selected = 0

    #   extra_context = {
    #    'title': 'Главная страница',
    #    'menu': menu,
    #    'posts': Woman.published.all().select_related('cat'),
    #    'cat_selected': 0,
    #}

    # переопределим метод базового класса get_context_data
    # данный метод срабатывает в момент прихода get-запроса
    # def get_context_data(self, **kwargs):
    #     context = super().get_context_data(**kwargs)
    #     context['title'] = "Главная страница"
    #     context['menu'] = menu
    #     context['posts'] = Woman.published.all().select_related('cat')
    #     context['cat_selected'] = int(self.request.GET.get('cat_id', 0))
    #     return context

    def get_queryset(self):
        return Woman.published.all().select_related('cat')

def show_post(request, post_slug):
    # либо отображаем запись из БД, либо генерируем исключение
    post = get_object_or_404(Woman, slug=post_slug)
    data = {
        'title': post.title,
        'menu': menu,
        'post': post,
        'cat_selected': 1
    }
    return render(request, 'woman/post.html', data)

# добавим класс-представление для замены функции show_post, наследуемый от DetailView - для отображения отдельных записей
# и от класса DataMixin
class ShowPost(DataMixin, DetailView):
    # атрибут model указывает, какую модель использовать для получения записи
    model = Woman
    # указываем путь к шаблону
    template_name = 'woman/post.html'
    # указываем переменную для маршрута, ту же , что и в urls.py
    # атрибут slug_url_kwarg используется для изменения имени переменной slug, по которой отбирается запись
    slug_url_kwarg = 'post_slug'
    # указываем имя переменной для шаблона
    # по умолчанию объект записи в шаблоне доступен через переменную object
    context_object_name = 'post'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        return self.get_mixin_context(context, title=context['post'].title)

    # метод get_object() предоставляет возможность выбора записи по собственному алгоритму
    def get_object(self, queryset=None):
        # отображаем только опубликованные записи
        return get_object_or_404(Woman.published, slug=self.kwargs[self.slug_url_kwarg])


# добавим функционал добавления статьи на сайт с формой
def addpage(request):
    if request.method == 'POST':
        # зададим объект класса AddPostForm с предаваемыми атрибутами: request.POST и request.FILES
        form = AddPostForm(request.POST, request.FILES)
        # проверяем валидность заполнения формы
        if form.is_valid():
            # отображаем 'очищенные данные в консоли'
            # print(form.cleaned_data)
            # try:
            #     Woman.objects.create(**form.cleaned_data)
            #     return redirect('home')
            # except:
            #     form.add_error(None, "Ошибка добавления поста")
            form.save()
            return redirect('home')
    else:
        form = AddPostForm()
    # коллекция request.GET/POST будет содержать данные с формы в зависимости от выбранного метода
    data = {
        'menu': menu,
        'title': 'Добавление статьи',
        'form': form
    }
    return render(request, 'woman/addpage.html', data)

# определим класс-представление
# наследуется от базового класса View
# class AddPage(View):
#     # определяем методы get и post, автоматизацию работы которых django берет на себя
#     def get(self, request):
#         form = AddPostForm()
#         data = {
#             'menu': menu,
#             'title': 'Добавление статьи',
#             'form': form,
#         }
#         return render(request, 'woman/addpage.html', data)
#
#     def post(self, request):
#         form = AddPostForm()
#         if form.is_valid():
#             form.save()
#             return redirect('home')
#
#         data = {
#             'menu': menu,
#             'title': 'Добавление статьи',
#             'form': form,
#         }
#         return render(request, 'woman/addpage.html', data)

class AddPage(PermissionRequiredMixin,LoginRequiredMixin , CreateView):
    """
    Определим класс-представление, наследуемый от базового FormView для создания формы
    Выше, в комментариях, мы определяли данный класс, но наследуемый от View
    Для определения прав пользователя используем класс PermissionRequiredMixin
    Также добавим наследование от класса LoginRequiredMixin для отображения страницы только для авторизованного пользователя
    В шаблон форма будет передаваться через переменную form,
    Также подобный функционал лучше реализовывать с помощью класса CreateView, в таком случае можно не прописывать метод form_valid
    Атрибуты:
    • form_class - Передаем ссылку на модель-форму
    • template_name - Передаем путь к маршруту
    • success_url - Передаем страницу, на которую будем перенаправлены при успешной обработке формы, с помощью функции reverse_lazy
    • extra_context - Передаем дополнительные атрибуты для отображения на сайте
    • permission_required - Прописываем разрешения пользователя для доступа к данной странице в формате 'приложение.действие_таблица'
    Методы:
    • form_valid - вызывается в момент отправки формы для валидации данных, в нём вызываем метод form.save() для сохранения записи
    """
    form_class = AddPostForm
    template_name = 'woman/addpage.html'
    # success_url = reverse_lazy('home')
    extra_context = {
        'menu': menu,
        'title': 'Добавление статьи',
    }
    permission_required = 'woman.add_woman'
    # указываем url-адрес, на который следует перенаправить неавторизованного пользователя
    # login_url = '/admin/'

    def form_valid(self, form):
        # commit=False - сохраняем объект без занесения в БД
        w = form.save(commit=False)
        w.author = self.request.user
        return super().form_valid(form)

"""Аналог класса выше, рекомендуемое представление"""
# class AddPage(CreateView):
#     model = Woman
#     fields = '__all__'
#     template_name = 'woman/addpage.html'
#     extra_context = {
#         'menu': menu,
#         'title': 'Добавление статьи',
#     }

class UpdatePage(PermissionRequiredMixin,DataMixin, UpdateView):
    """
    Класс-представление для обновления текущих статей
    """
    model = Woman
    fields = ['title', 'content', 'photo', 'is_published', 'cat']
    template_name = 'woman/addpage.html'
    success_url = reverse_lazy('home')
    title_page = 'Редактирование статьи'
    permission_required = 'woman.change_woman'

"""
Для настройки разрешения для функции представления 
используем декоратор permission_required
"""

@permission_required(perm='woman.view_woman', raise_exception=True)
def contact(request):
    """
    Функция-заглушка, для примера использования декоратора,
    используется класс ContactFormView
    """
    return HttpResponse("Обратная связь")

class ContactFormView(LoginRequiredMixin, DataMixin, FormView):
    form_class = ContactForm
    template_name = 'woman/contact.html'
    success_url = reverse_lazy('home')
    title_page = "Обратная связь"

    def form_valid(self, form):
        print(form.cleaned_data)
        return super().form_valid(form)

def login(request):
    return users.views.login_user(request)

def index(request): # HttpRequest
    t = render_to_string("woman/index.html") # внутри папки templates нужно указать папку с названием нашего приложения и уже там создать html-файл
    return HttpResponse(t) # передаем текстовый вариант нашего шаблона

# зададим функцию для чтения загруженных файлов с официальной страницы документации django
def handle_uploaded_file(f):
    with open(f"uploads/{f.name}", "wb+") as destination:
        for chunk in f.chunks():
            destination.write(chunk)

"""
Для того, чтобы добавить ограничения на просмотр страницы, 
мы можем воспользоваться декоратором login_required, 
который отображает страницу только для авторизованных пользователей
Дополнительно мы можем передать url страницы, на которую следует перенаправить неавторизованного пользователя
"""

@login_required(login_url='users:login')
def about(request):
    contact_list = Woman.published.all()
    # пагинация html-страницы для более удобного отображения
    paginator = Paginator(contact_list, 3)

    # по get-запросу page с номером получаем страницу
    page_number = request.GET.get('page')
    # подставляем в метод get_page полученное значения из коллекции GET
    # get_page - метод для получения объекта страницы с указанным номером, при неверном номере возвращается последняя страница
    page_obj = paginator.get_page(page_number)

    if request.method == 'POST':

        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            # handle_uploaded_file(form.cleaned_data['file'])
            fp = UploadFiles(file=form.cleaned_data['file'])
            fp.save()
    else:
        form = UploadFileForm()
    return render(request, 'woman/about.html', {'title':'о сайте', 'menu':menu,
                                                'form': form, 'page_obj': page_obj}) # передаем запрос, путь к шаблону и данные для него

def categories(request, cat_id):
    return HttpResponse(f"<h1>Статьи по категориям</h1><p>id: {cat_id}</p>")

def categories_by_slug(request, cat_slug):
    if request.GET:
        # http://127.0.0.1:8000/cat/music/?name=Gararina&type=pop
        # Знак вопроса(?) в URL используется для указания начала строки параметров(query string).
        # Строка параметров содержит пары ключ - значение, разделенные амперсандом( &).
        # <QueryDict: {'name': ['Gararina'], 'type': ['pop']}>
        print(request.GET) # выводим пару ключа-значение get-запроса
    if request.POST:
        # Вывод POST-запроса
        print(request.POST)
    return HttpResponse(f"<h1>Статьи по категориям</h1><p>id: {cat_slug}</p>")

def archive(request, year):
    if int(year) == 2022:
        # импортируем функцию redirect и указываем тот url, на который планируем делать перенаправление
        # например адрес страницы cat/slug
        # по умолчанию перенаправление с кодом 302, но если именованный параметр 'permanent' = True, то 301
        print('not ok')
        return redirect('cat_slug','authors', permanent=True)

    if int(year) == 2000:
        # разделяем операции вычисления url-адреса и перенаправления, с помощью функции reverse
        # аналог блока if выше
        uri = reverse('my_conv', args=(1999,))
        return redirect(uri)

    if int(year) == 1000:
        # воспользуемся классом HttpResponseRedirect для перенапправления на главную страницу
        return HttpResponseRedirect('/')

    # Если значение больше текущего кода то генерируем исключение
    if int(year) > datetime.now().year:
        raise Http404()
    return HttpResponse(f"<h1>Архив по годам</h1><p>{year}</p>")

def show_category(request, cat_slug):
    category = get_object_or_404(Category, slug=cat_slug)
    posts = Woman.published.filter(cat_id=category.pk).select_related('cat')
    data = {
        'title': f'Рубрика {category.name}',
        'menu': menu,
        'posts': posts,
        'cat_selected': category.pk,
    }  # создаем словарь с передаваемыми в шаблон значениями
    return render(request, 'woman/home_page.html', context=data)

# определим класс-представление для отображения статей по категориям, наследуемым от ListView
class WomanCategory(DataMixin, ListView):
    # путь к файлу шаблона
    template_name = 'woman/home_page.html'
    # имя переменной, передаваемой в шаблон, с коллекцией выбранных записей (для класса ListView)
    context_object_name = 'posts'
    # указываем атрибут allow_empty для генерации страницы 404 при пустом списке
    allow_empty = False

    # метод для формирования выборки записей
    def get_queryset(self):
        return Woman.published.filter(cat__slug=self.kwargs['cat_slug']).select_related("cat")

    # метод для формирования переменных для шаблона
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        cat = context['posts'][0].cat
        return self.get_mixin_context(context, title="Категория - " + cat.name, cat_selected=cat.pk,)

# определим функцию обработки несуществующего сайта
def page_not_found(request, exception):
    return HttpResponseNotFound("<h1>Страница не найдена</h1>")

def show_tag_postlist(request, tag_slug):
    tag = get_object_or_404(TagPost, slug=tag_slug)
    # берем все статьи, которые связаны с этим тегом
    posts = tag.tags.filter(is_published=Woman.Status.PUBLISHED).select_related('cat')

    data = {
        'title': f"Тэг:{tag.tag}",
        'menu': menu,
        'posts':posts,
        'cat_selected': None,
    }

    return render(request, 'woman/home_page.html', context=data)

# класс представление вместо show_tag_postlist
class TagPostList(ListView):
    template_name = 'woman/home_page.html'
    context_object_name = 'posts'
    allow_empty = False

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        tag = TagPost.objects.get(slug=self.kwargs['tag_slug'])
        context['title'] = "Тэг: " + tag.tag
        context['menu'] = menu
        context['cat_selected'] = None
        return context


    def get_queryset(self):
        return Woman.published.filter(tags__slug=self.kwargs['tag_slug']).select_related()