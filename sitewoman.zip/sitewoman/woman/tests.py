"""
На базе класса TestCase мы можем создавать собственные классы
И тестировать те или иные фрагменты сайта
У тестирующего метода всегда префикс test_
setUp и tearDown вызываются перед и после каждого теста соответственно
python manage.py test . - запуск тестов во всем проекте
python manage.py test woman - запуск теста в определенном приложении
python manage.py.test woman.tests.GetPagesTestCase - запуск определенной группы тестов
python manage.py.test woman.tests.GetPagesTestCase.test_case_1 - запуск определенного теста
"""
from http import HTTPStatus

from django.test import TestCase
from django.urls import reverse

from woman.models import Woman


# Create your tests here.

class GetPagesTestCase(TestCase):
    # перечисляем те фикстуры, которые будут загружаться в БД перед каждым тестом
    # для создания фикстур вводим в терминал команду: "python -Xutf8 manage.py dumpdata woman.woman -o woman/fixtures/woman_woman.json"
    fixtures = ['woman_woman.json', 'woman_category.json', 'woman_boyfriend.json', 'woman_tagpost.json']


    def setUp(self):
        "Инициализация перед выполнением каждого теста"

    def test_mainpage(self):
        path = reverse('home')
        response = self.client.get(path) # client позволяет имитировать запросы сервера
        self.assertEqual(response.status_code, HTTPStatus.OK) # asserEqual позволяет сравнивать возвращенный результат выполнения запроса
        self.assertIn('woman/home_page.html', response.template_name) # данный метод проверяет вхождение данного значения в коллекцию
        self.assertTemplateUsed(response, 'woman/home_page.html') # рекомендуемый к использованию аналог строки выше
        self.assertEqual(response.context_data['title'], "Главная страница") # проверка названия главной страницы

    def test_redirect_addpage(self):
        """
        Проверяем, происходит ли редирект на странице
        """
        path = reverse('add_page')
        redirect_uri = reverse('users:login') + '?next=' + path
        response = self.client.get(path)
        self.assertEqual(response.status_code, HTTPStatus.FOUND)
        self.assertRedirects(response, redirect_uri)

    def test_data_mainpage(self):
        w = Woman.published.all().select_related('cat')
        path = reverse('home')
        response = self.client.get(path)
        self.assertQuerySetEqual(response.context_data['posts'], w[:3]) # проверка равенства queryset

    def test_paginate_mainpage(self):
        """
        Проверка работы пагинации главной страницы
        """
        path = reverse('home')
        page = 2
        paginate_by = 3
        response = self.client.get(path + f'?page={page}') # имитируем запрос, создавая порядковый номер пагинации
        w = Woman.published.all().select_related('cat')
        self.assertQuerySetEqual(response.context_data['posts'], w[(page-1) * paginate_by:page * paginate_by])

    def test_content_post(self):
        """
        Проверка корректности содержимого страницы для отображения поста
        """
        w = Woman.published.get(pk=1)
        path = reverse('post', args=[w.slug])
        response = self.client.get(path)
        self.assertEqual(w.content, response.context_data['post'].content)

    def test_case_2(self):
        pass

    def tearDown(self):
        "Действия после выполнения каждого теста"