from django.urls import path, re_path, register_converter
from . import views # импортируем модуль из текущей директории
from . import converters # импортируем свой модуль конвертеров

register_converter(converters.FourDigitYearConverter, "year4") # для того, чтобы использовать свой конвертер, его нужно зарегистрировать

urlpatterns = [
    path('', views.WomanHome.as_view(), name='home'), # http://127.0.0.1:8000 Главная страница, добавляем имя для перенаправления
    path('woman/', views.index), # http://127.0.0.1:8000/woman/
    path('about/', views.about, name='about'),
    # Указываем конвертер <int:value>
    path('post/<slug:post_slug>/', views.ShowPost.as_view(), name='post'),
    path('cat/<int:cat_id>/', views.categories, name='cat_id'), # http://127.0.0.1:8000/cat/1/
    path('cat/<slug:cat_slug>/', views.categories_by_slug, name='cat_slug'), # http://127.0.0.1:8000/cat/abc/
    re_path(r"^archive/(?P<year>[0-9]{4})/", views.archive, name='archive'), # всё то же самое, что и path, но с использованием регулярных выражений
    path('myconv/<year4:year>/', views.archive, name='my_conv'), # использование своего конвертера, аналог строки выше
    path('addpage/', views.AddPage.as_view(), name='add_page'), # обращаемся к классу-представление и вызываем функцию as_view()
    path('contact/', views.ContactFormView.as_view(), name='contact'),
    path('login/', views.login, name='login'),
    path('category/<slug:cat_slug>/', views.WomanCategory.as_view(), name='category'),
    # маршрут для отображения тэгов
    path('tag/<slug:tag_slug>/', views.TagPostList.as_view(), name='tag'),
    path('edit/<slug:slug>/', views.UpdatePage.as_view(), name='edit_page' )
]

"""
Path converters
• str- Соответствует любой непустой строке, за исключением разделителя пути, '/'. Это значение по умолчанию, если преобразователь не включен в выражение.
• int- Соответствует нулю или любому положительному целому числу. Возвращает int.
• slug- Соответствует любой строке слага, состоящей из букв или цифр ASCII, а также символов дефиса и подчеркивания. Например, building-your-1st-django-site.
• uuid- Соответствует отформатированному UUID. Чтобы предотвратить сопоставление нескольких URL с одной и той же страницей, необходимо включить дефисы и использовать строчные буквы.
• path- Соответствует любой непустой строке, включая разделитель пути, '/'. Это позволяет сопоставлять полный путь URL, а не сегмент пути URL, как в случае str.
Если нам нужно разделять конвертеры, то сначала мы пишем более частный случай, затем общий
------------------------------------------------------------------------------------------------------------------------
Для использования своего конвертера нужно:
1. Создать файл с именем импортируемого конвертера в директории приложения
2. В файле мы прописываем наш класс конвертера, regex(регулярное выражение) и две функции: 
    • to_python(self, value) -> int(value)
    • to_url(self, value) -> f"{value:04d}"
3. Импортировать функцию register_converter из django.urls
4. Зарегистрировать с помощью функции register_converter()
"""