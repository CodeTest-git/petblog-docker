"""
Зачем нужен sitemap.xml:

1. Улучшение индексации:
Предоставляя поисковым системам sitemap.xml,
веб-мастеры помогают им понять структуру сайта и быстрее индексировать его содержимое.
Это особенно полезно для больших сайтов с множеством страниц.

2. Информация об изменениях:
Элемент <lastmod> позволяет поисковым системам определить,
когда страница была последний раз изменена.
Это может помочь в управлении процессом индексации.

3.Управление приоритетом и частотой обновлений:
Элементы <changefreq> и <priority> позволяют веб-мастерам указывать поисковым системам,
как часто они ожидают изменения на странице и насколько важны эти изменения по сравнению с другими страницами.
"""

from django.contrib.sitemaps import Sitemap

from woman.models import Woman, Category


class PostSitemap(Sitemap):
    changefreq = 'monthly' # Ожидаемая частота изменения страницы
    priority = 0.9 # Приоритет страницы относительно других страниц

    def items(self):
        return Woman.published.all()

    def lastmod(self, obj):
        "Последняя дата изменения страницы"
        return obj.time_update

class CategorySitemap(Sitemap):
    changefreq = 'monthly' # частота
    priority = 0.9 # приоритет

    def items(self):
        return Category.objects.all()

