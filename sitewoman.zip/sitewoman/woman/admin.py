from django.contrib import admin
from django.core.checks import messages
from django.db.models.functions import Length
from django.utils.safestring import mark_safe

from .models import Woman, Category
from users.models import User

# Register your models here.

# добавим свой фильтр для отображения в админ-панели
class  ContactFilter(admin.SimpleListFilter):
    title = "Статус женщин"
    parameter_name = 'status'

    def lookups(self, request, model_admin):
        return [
            ('contact', 'В отношениях'),
            ('single', 'Не в отношениях'),
        ]

    def queryset(self, request, queryset):
        if self.value() == 'contact':
            return queryset.filter(boyfriend__isnull=False)
        elif self.value() == 'single':
            return queryset.filter(boyfriend__isnull=True)

# добавим отображение параметров существующих статей в админ-панели
class WomanAdmin(admin.ModelAdmin):
    # выбираем поля, которые будут отображаться при редактировании статьи,
    # по умолчанию эту коллекцию можно не указывать и будут отображаться все поля
    # также можно указать коллекцию exclude, она наоборот исключает поля
    fields = ['title', 'slug', 'content', 'photo', 'post_photo', 'cat', 'boyfriend', 'tags']
    # настроим вид поля tags
    filter_horizontal = ['tags']
    # добавим автоматическое формирование слага для записи
    prepopulated_fields = {'slug': ('title',)}
    # указываем поля только для чтения
    readonly_fields = ['post_photo']
    # для отображения параметров есть специальный атрибут - list_display
    list_display = ('id', 'title', 'post_photo', 'time_create', 'is_published', 'cat', 'brief_info')
    # делаем статьи "кликабельными" в админ-панели
    list_display_links = ('id',)
    # порядок сортировки
    ordering = ['time_create', 'title']
    # список полей для редактирования
    list_editable = ('is_published', 'title', 'cat',)
    # настроим пагинацию списка
    list_per_page = 5
    # добавляем действие
    actions = ['set_published', 'set_draft']
    # добавим список полей, по которым будет осуществляться поиск
    # поскольку поле cat - это поле связанной таблицы, то мы должны обращаться к конкретному полю через два подчеркивания, как и с люкапами
    search_fields = ['title', 'cat__name']
    # добавим панель фильтрации по полям
    list_filter = [ContactFilter, 'cat__name', 'is_published']
    # добавим также панель с сохранением изменений вверх редактируемой статьи
    save_on_top = True

    # настроим поле, которое будет отображаться в админ-панели, но которого нет в базе данных
    @admin.display(description="Краткое описание", ordering=Length('content'))
    def brief_info(self, woman: Woman):
        return f"Описание {len(woman.content)} символов"

    @admin.display(description="Изображение")
    def post_photo(self, woman: Woman):
        if woman.photo:
            # импортируем функцию mark_safe для того, чтобы html-тэги не экранировались
            return mark_safe(f"<img src='{woman.photo.url}' width=50 >")
        return "Без фото"

    # добавляем своё действие в выпадающем поле
    @admin.action(description="Опубликовать выбранные записи")
    def set_published(self, requets, queryset):
        count = queryset.update(is_published=Woman.Status.PUBLISHED)
        # выводим сообщение о том, сколько записей было изменено
        self.message_user(requets, f"Изменено {count} записей")

    @admin.action(description="Снять с публикации выбранные записи")
    def set_draft(self, requets, queryset):
        count = queryset.update(is_published=Woman.Status.DRAFT)
        # выводим сообщение о том, сколько записей было изменено, атрибут WARNING меняет значок у сообщения
        self.message_user(requets, f"{count} записей снято с публикации", messages.WARNING)

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')
    list_display_links = ('id', 'name')



# регистрируем нашу модель, можно через декоратор
admin.site.register(Woman, WomanAdmin)
admin.site.site_header = "Панель администрирования"
admin.site.index_title = "Известные женщины мира"