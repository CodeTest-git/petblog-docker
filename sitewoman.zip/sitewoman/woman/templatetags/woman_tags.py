from django import template
from django.db.models import Count

import woman.views as views
from woman.models import Category, TagPost
from woman.utils import menu

# Создаем объект класса Library для регистрации наших тегов
register = template.Library()

# создаём простой тэг с помощью декоратора,
# мы можем воспользоваться им в любом шаблоне нашего проекта
@register.simple_tag(name='getcats')
def get_categories():
    return views.cats_db

# отличие inclusion_tag от simple_tag состоит в том, что inclusion_tag возвращает фрагмент html-страницы,
# а simple_tag возвращает данные

@register.inclusion_tag('woman/list_categories.html')
def show_categories(cat_selected=0):
    # на уровне orm django выполним запрос и отобразим те категории, которые имеют хотя бы одну запись
    cats = Category.objects.annotate(total=Count("post")).filter(total__gt=0)
    return {'cats':cats, 'cat_selected': cat_selected}

# указываем отображение статей в сайдбаре
@register.inclusion_tag('woman/list_tags.html')
def show_all_tags():
    return {'tags':TagPost.objects.annotate(total=Count("tags")).filter(total__gt=0)}

# указываем тэг для шаблонизатора base.html для отображения меню в панели авторизации
@register.simple_tag
def get_menu():
    return menu