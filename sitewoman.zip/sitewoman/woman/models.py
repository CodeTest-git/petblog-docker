from django.contrib.auth import get_user_model
from django.db import models
from django.urls import reverse
from django.utils.text import slugify
from unidecode import unidecode

# Create your models here.
"""
ORM:
 • Класс - таблица БД, иначе модель
 • Объект класса - это запись из таблицы БД 
"""

"""
Некоторые методы выборки записей с помощью ORM django:

 • Woman.objects.order_by("pk").all() - Сортировка по Primary Key по возрастанию
 • Woman.objects.order_by(-"pk").all() - Сортировка по Primary Key по убыванию
 • Woman.objects.filter(pk__in=[2, 5, 7, 10], is_published=True) - В данном случае используем люкап __in для проверки вхождения
 • Woman.objects.all().earliest("time_update") - Выбираем поле с самой ранней датой обновления 
 • Woman.objects.all().latest("time_update") - Выбираем поле с самой поздней датой обновления 
 • Woman.objects.filter(pk__lt=4).latest("time_update") - Выбираем поле с самой ранней датой обновления и используем люкап __lt для указания, что значение pk должно быть меньше
 • w.get_previous_by_time_update() - получаем предыдущую запись относительно текущей (w), по заданному полю (time_update)
 • w.get_next_by_time_update() - получаем следующую запись относительно текущей (w), по заданному полю (time_update)
 • Woman.objects.filter(pk__gt=F("cat_id")) - применяем F-класс для получения статей, где pk больше, чем cat_id
 • F-классы также нужны для ПОЛУЧЕНИЯ И ОБНОВЛЕНИЯ данных по полю, например: Boyfriend.objects.update(age=F("age")+1)
 • Value-класс позволяет формировать новые временные вычиляемые поля для выборки в совокупности с методом annotate, например Boyfriend.objects.all().annotate(money_count=Value(1000000))
 • Boyfriend.objects.all().annotate(work_age=F("age"-20)) - Задаем поле work_age , где отобразим стаж работы с помощью F-класса
 • Агрегирующие функции: Count, Sum, Avg, Max, Min. Вызывается с помощью метода aggregate, Например: Boyfriend.objects.aggregate(Min("age"))
 • Boyfriend.objects.aggregate(young=Min('age'), old=Max('age')) - определяем записи с минимальным возрастом и максимальным
 • Woman.objects.values("title", "cat_id") - отобрать записи по указанным полям
 • Woman.objects.values("cat_id").annotate(total=Count("id")) - выполняем группировку по полю cat_id и вычисляем количество значений в каждой группе
 • метод exists() проверяет, есть ли запись в нашей выборке
 • метод count() выводит количство записей в выборке (c.posts.count())
"""

"""
Типы связей между таблицами:
 • ForeignKey - для связей Many to One (многие к одному, например таблица с категориями)
 • ManyToManyFields - для связей Many To Many (многие ко многим, например таблица студентов-преподавателей)
 • OneToOneField - для связей One To One (один к одному, например таблица с паспортными данными)
"""

"""
Параметры on_delete:
 • models.CASCADE - при удалении записи из первичной модели (в данном случае таблицы Category)
 происходит удаление всех записей из вторичной модели (Woman), связынных с удаляемой категорией
 • models.PROTECT - запрещает удаление записи из первичной модели, если она используется во вторичной
 (выдает исключение)
 • models.SET_NULL - при удалении записи первичной модели устанавливает значение foreign key в NULL
 у соответствующих записей вторичной модели
 • models.SET_DEFAULT - то же самое, что и SET_NULL, только вместо значения NULL устанавливает значение
 по умолчанию, которое должно быть опеределено через класс ForeignKey
 • models.DO_NOTHING - удаление записи в первичной модели не вызывает никаких действий у вторичных моделей
"""

"""
null разрешает NULL значение в поле; 
blank поволяет его совсем не заполнять;
"""

# определяем собственный менеджер записей
class PublishedManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(is_published=Woman.Status.PUBLISHED)


# именно наследование превращает наш класс в класс модели
class Woman(models.Model):
    # определим класс для поля is_published
    class Status(models.IntegerChoices):
        DRAFT = 0, 'Черновик'
        PUBLISHED = 1, 'Опубликовано'

    title = models.CharField(max_length=255, verbose_name="Заголовок")
    # задаем слаги для страниц
    slug = models.SlugField(max_length=255, unique=True, db_index=True, default='', verbose_name="Slug")
    # загружаем изображения в каталог photos с текущем месяцем, годом, днем
    photo = models.ImageField(upload_to="photos/%Y/%m/%d/", default=None, blank=True, null=True, verbose_name="Фото")
    content = models.TextField(blank=True, verbose_name="Текст статьи")
    time_create = models.DateTimeField(auto_now_add=True, verbose_name="Время создания")
    time_update = models.DateTimeField(auto_now=True, verbose_name="Время изменения")
    is_published = models.BooleanField(choices=tuple(map(lambda x: (bool(x[0]), x[1]), Status.choices)),
                                       default=Status.DRAFT, verbose_name="Статус")
    # определяем параметр для связи модели по категориям, cat - полноценный объект класс Category
    # также создается поле cat_id - порядковый номер,
    # ВАЖНО! Если мы удаляем объект из записи, то нужно не забыть в самой таблице сбросить счетчик автоинкремента
    # также мы можем указать параметр related_name, который заменяет стандартный атрибут woman_set для получения записей по категориям
    cat = models.ForeignKey('Category', on_delete=models.PROTECT, null=True, related_name='post', verbose_name="Категории")
    # установим связь Many To Many
    tags = models.ManyToManyField('TagPost', blank=True, related_name='tags', verbose_name="Теги")
    # установим связь One To One
    boyfriend = models.OneToOneField('Boyfriend', on_delete=models.SET_NULL, null=True, blank=True, related_name='woman', verbose_name="Парень")

    # как только в модели мы определяем экземпляр класса своего менеджера, стандартный менеджер objects перестает существовать
    # но его можно вручную прописать
    objects = models.Manager()
    published = PublishedManager()
    # указываем автора статьи
    author = models.ForeignKey(get_user_model(), on_delete=models.SET_NULL, related_name='posts', null=True, default=None)

    def __str__(self):
        return self.title

    # используем вложенный класс Meta для сортировки и индексирования
    class Meta:
        # указываем желаемое имя для отображения в админ-панели
        verbose_name = "Известные женщины"
        verbose_name_plural = "Известные женщины"
        # указываем сортировку по умолчанию
        ordering = ['-time_create']
        # индексируем поля, чтобы ускорить сортировку
        indexes = [
            models.Index(fields=['-time_create'])
        ]

    def get_absolute_url(self):
        return reverse('post', kwargs={'post_slug': self.slug})

    # добавим автоматическое формирование слага для записи
    # def save(self, *args, **kwargs):
        # self.slug = slugify(unidecode(str(self.title)))
        # super().save(*args, **kwargs)

# определим модель для связи таблиц по категориям
class Category(models.Model):
    name = models.CharField(max_length=100, db_index=True, verbose_name="Категория")
    slug = models.SlugField(max_length=255, unique=True, db_index=True)

    class Meta:
        verbose_name = "Категория"
        verbose_name_plural = "Категории"

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('category', kwargs={'cat_slug':self.slug})

# определим модель для тегов
class TagPost(models.Model):
    tag = models.CharField(max_length=100, db_index=True)
    slug = models.SlugField(max_length=255, unique=True, db_index=True)

    def __str__(self):
        return self.tag

    # возвращаем url-адрес для конкретного тэга
    def get_absolute_url(self):
        return reverse('tag', kwargs={'tag_slug':self.slug})

# Определим связь One To One, создав модель Boyfriend для модели Woman
class Boyfriend(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField(null=True)

    def __str__(self):
        return self.name

# определим модель для загрузки файлов
class UploadFiles(models.Model):
    # класс FileField автоматически и загружает файл, и добавляет в БД
    file = models.FileField(upload_to='uploads_model')

