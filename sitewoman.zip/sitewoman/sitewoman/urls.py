"""
URL configuration for sitewoman project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from django.views.decorators.cache import cache_page

from sitewoman import settings
from woman import views
from woman.sitemaps import PostSitemap, CategorySitemap
from woman.views import page_not_found
from debug_toolbar.toolbar import debug_toolbar_urls

from django.contrib.sitemaps.views import sitemap

sitemaps = {
    'posts': PostSitemap,
    'cats': CategorySitemap,
}

# здесь хранятся шаблоны маршрутов для url-запросов
# с помощью функции include мы можем подключить все необходимые маршруты,
# что помогает обеспечить относительную независимость нашего приложаения, относительно основного проекта
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('woman.urls')),  # http://127.0.0.1:8000 Главная страница
    path('users/', include('users.urls', namespace="users")), # добавляем авторизацию на сайте, namespace позволяет вводить users: login/logout, дополнительная изоляция переменных
    path('all/', include('woman.urls')),  # добавляется /all ко всем страницам https://127.0.0.1:8000/all/woman
    path('social-auth/', include('social_django.urls', namespace='social')), # добавляем авторизацию по социальным сетям
    path('captcha/', include('captcha.urls')), # добавляем капчу на страницу формы обратной связи
    path('sitemap.xml', cache_page(86400)(sitemap), {'sitemaps': sitemaps}, name="django.contrib.sitemaps.views.sitemap"), # добавляем карту сайта
] + debug_toolbar_urls()

# благодаря MEDIA_URL определенному в settings.py, мы можем расширить urlpatterns
if settings.DEBUG:
    # условие прописываем только в режиме отладки
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# пропишем специальный обработчик ошибки несуществующей страницы
# переменные, которые используется в качестве исключений можно посмотреть на https://docs.djangoproject.com/en/4.2/ref/urls/

handler404 = page_not_found

