from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.views import LoginView, PasswordChangeView
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse, reverse_lazy
from django.views.generic import CreateView, UpdateView

from sitewoman import settings
from users.forms import LoginUserForm, RegisterUserForm, ProfileUserForm, UserPasswordChangeForm

"""
    • LoginView - класс представления для авторизации пользователей
    • LogoutView - класс представления для выхода пользователя из системы
    • AuthenticationForm - класс формы обработки аутентификации пользователя
"""

# Create your views here.
class LoginUser(LoginView):
    """
    Класс-представление для авторизации пользователя
    в form_class указываем AuthenticationForm, поскольку данный класс работает в связке с LoginView
    """
    form_class = LoginUserForm
    template_name = 'users/login.html'
    extra_context = {'title': 'авторизация'}

    # def get_success_url(self):
    #     """
    #     Переопределяем данный метод,
    #     поскольку при авторизации django по умолчанию перенаправляет на 'profile/',
    #     укажем маршрут, который мы должны возвратить при успешной авторизации
    #     """
    #     return reverse_lazy('home')


# def login_user(request):
#     if request.method == 'POST':
#         # создадим экземпляр класса LoginUserForm для отображения формы логина
#         form = LoginUserForm(request.POST)
#         if form.is_valid():
#             # получаем коллекцию из 'очищенных' данных
#             cd = form.cleaned_data
#             # используем функцию django для аутентификации пользователя
#             user = authenticate(request, username=cd['username'],
#                                 password=cd['password'])
#
#             # если пользователь существует и он активен, то проверка проходит
#             if user and user.is_active:
#                 # авторизация пользователя через функцию login django
#                 login(request, user)
#                 return HttpResponseRedirect(reverse('home'))
#
#     else:
#         # задаем пустую форму
#         form = LoginUserForm()
#     # формируем ответ для пользователя
#     return render(request, 'users/login.html', {'form': form})

def logout_user(request):
    # используем функцию logout фреймворка django
    logout(request)
    # прописываем дополнительно users, поскольку в приложении woman также есть функция-пресдтавление с именем login
    return HttpResponseRedirect(reverse('users:login'))

class RegisterUser(CreateView):
    """
    В django нет специального класса для регистрации пользователей,
    поскольку всё, что нам нужно сделать - это проверить данные формы и сохранить в БД,
    а для этого уже есть класс-представления CreateView
    """
    form_class = RegisterUserForm
    template_name = 'users/register.html'
    extra_context = {'title': 'Регистрация'}
    # указываем url-адрес, на который перенаправляем пользователя после успешной регистрации
    success_url = reverse_lazy('users:login')

class ProfileUser(LoginRequiredMixin, UpdateView):
    """
    Класс-представление для отображения профиля пользователя
    LoginRequiredMixin позволяет отображать страницу только для авторизованных пользователей,
    А UpdateView - редактировать записи
    """
    model = get_user_model()
    form_class = ProfileUserForm
    template_name = 'users/profile.html'
    extra_context = {
        'title': "Профиль пользователя",
        'default_image': settings.DEFAULT_USER_IMAGE,
        }

    def get_success_url(self):
        """Данный метод перенаправляет на текущую страницу"""
        return reverse_lazy('users:profile')

    def get_object(self, queryset=None):
        """
        Данный метод позволяет оотбирать ту запись, которая будет отображаться и редактироваться,
        Возвращаем текущего пользователя, который уже находится в коллекции request
        """
        return self.request.user

class UserPasswordChange(PasswordChangeView):
    """
    Класс-пресдтавление для отображения формы смены пароля
    """
    form_class = UserPasswordChangeForm
    success_url = reverse_lazy("users:password_change_done")
    template_name = "users/password_change_form.html"


def register(request):
    """
    Вариант функции-представления, аналог класса RegisterUser,
    не используется
    """
    if request.method == 'POST':
        form = RegisterUserForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            return render(request, 'users/register_done.html')
    else:
        form = RegisterUserForm()
    return render(request, 'users/register.html', {'form': form})
