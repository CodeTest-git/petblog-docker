from django.contrib.auth.views import LogoutView, PasswordChangeView, PasswordChangeDoneView, PasswordResetView, \
    PasswordResetDoneView, PasswordResetConfirmView, PasswordResetCompleteView
from django.urls import path, reverse_lazy
from . import views # импортируем модуль из текущей директории

"""
переменная app_name используется для задания пространства имен (namespace)
для URL-адресов этого приложения
Когда мы подключаем маршрут через include, мы указываем данный параметр,
поэтому app_name нужно обязательно указывать, во избежание ошибок и сбоев приложения
"""
app_name = "users"

urlpatterns = [
    # Авторизация
    path('login/', views.LoginUser.as_view(), name='login'),
    # Выход из аккаунта
    path('logout/', LogoutView.as_view(), name='logout'),
    # Регистрация
    path('register/', views.RegisterUser.as_view(), name='register'),
    # Изменение профиля
    path('profile/', views.ProfileUser.as_view(), name='profile'),
    # Смена пароля
    path('password-change/', views.UserPasswordChange.as_view(), name='password_change'),
    # Сообщение об успешной смене пароля
    path('password-change/done/', PasswordChangeDoneView.as_view(template_name="users/password_change_done.html"), name='password_change_done'),
    # Восстановление пароля
    path('password-reset/',
         PasswordResetView.as_view(template_name="users/password_reset_form.html",
                                   email_template_name="users/password_reset_email.html",
                                   success_url=reverse_lazy("users:password_reset_done")),
         name='password_reset'),
    # Сообщение об отправке ссылки для восстановления пароля
    path('password-reset/done/',PasswordResetDoneView.as_view(template_name="users/password_reset_done.html"),
         name='password_reset_done'),
    # Вход по ссылке для восстановления пароля
    path('password-reset/<uidb64>/<token>/',
         PasswordResetConfirmView.as_view(template_name="users/password_reset_confirm.html",
                                          success_url=reverse_lazy("users:password_reset_complete"),),
         name='password_reset_confirm'),
    # Сообщение об успешном восстановлении пароля
    path('password-reset/complete/', PasswordResetCompleteView.as_view(template_name="users/password_reset_complete.html"),
         name='password_reset_complete'),
]

"""
PasswordResetView - для отображения формы ввода E-mail адреса при восстановлении пароля
PasswordResetDoneView - для отображения страницы сброса на E-mail инструкций восстановления пароля
PasswordResetConfirmView - для отображения формы создания нового пароля (при его восстановлении)
PasswordResetCompleteView - для отображения страницы успешности изменения пароля (при его восстановлении)
PasswordChangeView - для отображения формы изменения пароля у авторизованного пользователя
PasswordChangeDoneView - для отображения страницы успешного изменения пароля у авторизованного пользователя
"""