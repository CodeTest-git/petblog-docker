"""
Зададим отображение формы авторизации пользователя
"""
import datetime

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm, PasswordChangeForm


class LoginUserForm(AuthenticationForm):
    username = forms.CharField(label="Логин",
                               widget=forms.TextInput(attrs={'class': 'form-input'}) )
    password = forms.CharField(label="Пароль",
                               widget=forms.PasswordInput(attrs={'class': 'form-input'}))

    class Meta:
        """
        Свяжем модель с объектом формы через функцию get_user_model,
        поскольку название модели может измениться
        """
        model = get_user_model()
        fields = ['username', 'password']

class RegisterUserForm(UserCreationForm):
    """
    Поскольку при регистрации пользователя будет добавляться новая запись в БД,
    значит форма должна быть связана с моделью, наследуем от UserCreationForm/forms.ModelForm
    Принципиальной разницы в наследовании нет, но лучше использовать UserCreationForm,
    поскольку можно не указывать лишние валидаторы, по типу проверки паролей
    """
    username = forms.CharField(label="Логин", widget=forms.TextInput(attrs={'class': 'form-input'}))
    password1 = forms.CharField(label="Пароль", widget=forms.PasswordInput(attrs={'class': 'form-input'}))
    password2 = forms.CharField(label="Повтор пароля", widget=forms.PasswordInput(attrs={'class': 'form-input'}))

    class Meta:
        # возвращаем текущую модель пользователя
        model = get_user_model()
        fields = ['username', 'email', 'first_name', 'last_name', 'password1', 'password2']
        labels = {
            'email': 'E-mail',
            'first_name': 'Имя',
            'last_name': 'Фамилия',
        }
        # укажем стили для всех остальных полей
        widgets = {
            'e-mail': forms.TextInput(attrs={'class': 'form-input'}),
            'first_name': forms.TextInput(attrs={'class': 'form-input'}),
            'last_name': forms.TextInput(attrs={'class': 'form-input'}),
        }

    """def clean_password2(self):
        "Указываем собственный валидатор введенного пороля с помощью префикса 'clean'"
        cd = self.cleaned_data
        if cd['password'] != cd['password2']:
            raise forms.ValidationError("Пароли не совпадают!")
        return cd['password']"""

    def clean_email(self):
        "Благодаря данной проверке каждый пользователь имеет уникальный email-адрес"
        email = self.cleaned_data['email']
        # проверка на существование записи с текущим e-mail
        if get_user_model().objects.filter(email=email).exists():
            raise forms.ValidationError("Такой E-mail уже существует")
        return email

class ProfileUserForm(forms.ModelForm):
    """
    Определим класс отображения профиля пользователя
    В передаваемые поля дополнительно указываем атрибут disabled=True, т.к. нельзя менять эти данные,
    Поскольку они используются для аутентификации пользователя
    """
    username = forms.CharField(disabled=True, label="Логин", widget=forms.TextInput(attrs={'class': 'form-input'}))
    email = forms.CharField(disabled=True, required=False, label="Email", widget=forms.TextInput(attrs={'class': 'form-input'}))
    this_year = datetime.date.today().year
    date_birth = forms.DateField(widget=forms.SelectDateWidget(years=tuple(range(this_year-100, this_year-5))))

    class Meta:
        model = get_user_model()
        fields = ['photo', 'username', 'email', 'date_birth', 'first_name', 'last_name']
        labels = {
            'first_name': 'Имя',
            'last_name': 'Фамилия',
        }
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-input'}),
            'last_name': forms.TextInput(attrs={'class': 'form-input'}),
        }

class UserPasswordChangeForm(PasswordChangeForm):
    """
    Класс формы для смены пароля
    """
    old_password = forms.CharField(label="Старый пароль", widget=forms.PasswordInput(attrs={'class':'form-input'}))
    new_password1 = forms.CharField(label="Новый пароль", widget=forms.PasswordInput(attrs={'class':'form-input'}))
    new_password2 = forms.CharField(label="Подтверждение пароля", widget=forms.PasswordInput(attrs={'class':'form-input'}))

