"""
Зададим свой контекстный процессор для передачи отображения меню
"""

from woman.utils import menu

def get_woman_context(request):
    """
    Тот словарь, который мы возвращаем, будет автоматически передаваться в шаблоны
    """
    return {'mainmenu': menu}