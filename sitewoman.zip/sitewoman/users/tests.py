from http import HTTPStatus

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse


# Create your tests here.

class RegisterUserTestCase(TestCase):
    """
    Класс для тестирования формы регистрации
    """

    def setUp(self):
        """
        Определим общий словарь данных
        """
        self.data = {
            'username': 'user_1',
            'email': 'kfdjhgkdsdhjklcxitoepsafgf@gmail.com',
            'first_name': 'Test',
            'last_name': 'Case',
            'password1': '12345678ABC',
            'password2': '12345678ABC',
        }


    def test_form_registration_get(self):
        """
        проверяем корректность формирования страницы регистрации
        """
        path = reverse('users:register')
        response = self.client.get(path)
        self.assertEqual(response.status_code, HTTPStatus.OK)
        self.assertTemplateUsed(response, 'users/register.html')

    def test_user_registration_success(self):
        """
        Проверка корректности регистрации пользователя
        """

        user_model = get_user_model()
        path = reverse('users:register')
        response = self.client.post(path, self.data)
        self.assertEqual(response.status_code, HTTPStatus.FOUND) # проверяем, что страница найдена
        self.assertRedirects(response, reverse('users:login')) # проверяем редирект на страницу авторизации
        self.assertTrue(user_model.objects.filter(username=self.data['username']).exists()) # проверяем, действительно ли пользователь был зарегистрирован и занесен в БД

    def test_user_registration_password_error(self):
        """
        Тестирование ошибок при регистрации пользователя
        """
        self.data['password2'] = '12345678ABc'
        path = reverse('users:register')
        response = self.client.post(path, self.data)
        self.assertEqual(response.status_code, HTTPStatus.OK)
        self.assertContains(response, "Введенные пароли не совпадают.", html=True) # html=True - вхождение строки проверяется на уровне всего htnl-тэга
        self.assertContains(response, "Введенные пароли не совпадают")

    def test_user_registration_exists_error(self):
        """
        Тест на созданного пользователя
        """
        user_model = get_user_model()
        user_model.objects.create(username=self.data['username'])
        path = reverse('users:register')
        response = self.client.post(path, self.data)
        self.assertEqual(response.status_code, HTTPStatus.OK)
        self.assertContains(response,"Пользователь с таким именем уже существует")
